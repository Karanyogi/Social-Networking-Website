from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm



# meta class cocept----class is object that use to create object of our rules -
# meta class is higher class that use to create object class

class UserCreateForm(UserCreationForm):

    class Meta:
        fields = ('username','email','password1','password2')
        model = get_user_model()

    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.fields['username'].label = "Display Name"
        self.fields['email'].label = "Email Address"
        self.fields['password1'].label = "Set a Password"
        self.fields['password2'].label = "confirm password"
